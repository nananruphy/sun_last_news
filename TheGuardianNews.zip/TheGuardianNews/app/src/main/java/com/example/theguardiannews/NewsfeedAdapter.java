package com.example.theguardiannews;

import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;

import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class NewsfeedAdapter extends ArrayAdapter<Newsfeed> {
    ViewHolder holder;

    public NewsfeedAdapter(Activity context, ArrayList<Newsfeed> news){
        super(context,0,news);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Newsfeed currentInfo = getItem(position);

        String titles = currentInfo.getTitles();
        String categoryName = currentInfo.getCategoryName();



        holder.category_tv.setText(categoryName);
        holder.titles_tv.setText(titles);

        List<String> authorList = currentInfo.getContributor();

        String authorText = "";


        if (authorList.size() > 0) {
            for (String s: authorList){
                authorText += s + ", ";
            }
            int len = authorText.length();
            String newText = authorText.substring(0,len-2);
            holder.author_tv.setText(newText);
        }
        else {
            holder.author_tv.setVisibility(View.GONE);
        }


        return convertView;
    }


    static class ViewHolder{
        @BindView(R.id.category_tv) TextView category_tv;
        @BindView(R.id.titles_tv) TextView titles_tv;
        @BindView(R.id.author_tv) TextView author_tv;

        public ViewHolder(View view) {
            ButterKnife.bind(this,view);
        }
    }
}
