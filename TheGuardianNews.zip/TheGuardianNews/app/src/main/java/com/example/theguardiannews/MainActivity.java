package com.example.theguardiannews;

import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<Newsfeed>> {
    private static final String LOG_TAG = MainActivity.class.getSimpleName();

    private static final int NEWS_LOADER_ID = 0;

    private NewsfeedAdapter mAdapter;

    private static final String REQUEST_URL = "http://content.guardianapis.com/search?q=debates&api-key=test\n";
    private TextView mEmptyStateTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView newsfeedListView = (ListView) findViewById(R.id.list);

        mEmptyStateTextView = (TextView) findViewById(R.id.empty_view);
        newsfeedListView.setEmptyView(mEmptyStateTextView);

        mAdapter = new NewsfeedAdapter(this, new ArrayList<Newsfeed>());

        newsfeedListView.setAdapter(mAdapter);

        newsfeedListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Newsfeed currentNewsfeed = mAdapter.getItem(position);
                Uri newsUrl = Uri.parse(currentNewsfeed.getUrl());
                Intent websiteIntent = new Intent(Intent.ACTION_VIEW, newsUrl);
                startActivity(websiteIntent);
            }
        });
        //public void load () {
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()) {
            android.app.LoaderManager loaderManager = getLoaderManager();
            Log.i(LOG_TAG, "TEST: print calling initLoader() ...");
            loaderManager.initLoader(NEWS_LOADER_ID, null, this);
        } else {
            View loading = findViewById(R.id.loading_spinner);
            loading.setVisibility(View.GONE);
            mEmptyStateTextView.setText("No data");

        }
    }
/**

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_refresh:
                Toast.makeText(this, "Refreshing page", Toast.LENGTH_SHORT)
                        .show();
                Intent refresh = new Intent(this,MainActivity.class);
                startActivity(refresh);
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
**/
    @Override
    public Loader<List<Newsfeed>> onCreateLoader(int id, Bundle args) {
        Log.i(LOG_TAG, "TEST: onCreateLoader() called");
        return new NewsfeedLoader(this, REQUEST_URL);
    }

    @Override
    public void onLoadFinished(Loader<List<Newsfeed>> loader, List<Newsfeed> news) {
        Log.i(LOG_TAG, "TEST: onLoadFinished() called");
        View loading = findViewById(R.id.loading_spinner);
        loading.setVisibility(View.GONE);

        mEmptyStateTextView.setText("no data");
        mAdapter.clear();
        if (news != null && !news.isEmpty()) {
            mAdapter.addAll(news);
        }
    }

    @Override
    public void onLoaderReset(Loader<List<Newsfeed>> loader) {
        Log.i(LOG_TAG, "TEST: onLoaderReset() called");
        mAdapter.clear();
    }
}