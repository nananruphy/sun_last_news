package com.example.theguardiannews;

import android.content.Context;
import android.util.Log;

import androidx.loader.content.AsyncTaskLoader;

import java.util.List;

public class NewsfeedLoader extends AsyncTaskLoader<List<Newsfeed>> {
    private static final String LOG_TAG = NewsfeedLoader.class.getName();

    private String mUrl;

    public NewsfeedLoader(Context context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() {
        Log.i(LOG_TAG, "Test: onStartLoading()...");
        forceLoad();
    }

    @Override
    public List<Newsfeed> loadInBackground() {
        Log.i(LOG_TAG, "Test: loadInBackground()...");
        if (mUrl == null) {
            return null;
        }

        List<Newsfeed> news = Utils.fetchNewsData(mUrl);
        return news;
    }
}
